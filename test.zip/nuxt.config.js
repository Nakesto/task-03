export default {
  // Disable server-side rendering: https://go.nuxtjs.dev/ssr-mode
  ssr: false,

  // Global page headers: https://go.nuxtjs.dev/config-head
  head: {
    title: "boot-test",
    htmlAttrs: {
      lang: "en",
    },
    meta: [
      { charset: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { hid: "description", name: "description", content: "" },
      { name: "format-detection", content: "telephone=no" },
    ],
    link: [{ rel: "icon", type: "image/x-icon", href: "/favicon.ico" }],
    script: [
      {
        src: "/assets/js/core/jquery.3.2.1.min.js",
      },
      {
        src: "/assets/js/core/popper.min.js",
      },
      {
        src: "assets/js/core/bootstrap.min.js",
      },
      {
        src: "/assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js",
      },
      {
        src: "/assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js",
      },
      {
        src: "/assets/js/plugin/bootstrap-toggle/bootstrap-toggle.min.js",
      },
      {
        src: "/assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js",
      },
      {
        src: "/assets/js/atlantis.min.js",
      },
    ],
  },

  // Global CSS: https://go.nuxtjs.dev/config-css
  css: [
    "@/assets/css/bootstrap.min.css",
    "@/assets/css/atlantis.css",
    "@/assets/css/fonts.min.css",
  ],

  // Plugins to run before rendering page: https://go.nuxtjs.dev/config-plugins
  plugins: [],

  // Auto import components: https://go.nuxtjs.dev/config-components
  components: true,

  // Modules for dev and build (recommended): https://go.nuxtjs.dev/config-modules
  buildModules: [],

  // Modules: https://go.nuxtjs.dev/config-modules
  modules: [],

  // Build Configuration: https://go.nuxtjs.dev/config-build
  build: {},
};
